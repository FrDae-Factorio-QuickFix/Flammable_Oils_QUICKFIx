# contributor
## by date order
- Klonan
- DarkyPupu 0.2.2 - v0.18
- Fr_Dae 0.2.3 - v0.18
- Hannah97Gamer 0.2.09 - v1.1
- Skorpyo 0.2.010 - v1.1 pvp version
- Kannagimoe 0.2.15 - v2.0
- lilys-incendiaries (lily) 0.2.15 - v2.0, review
- IonShield(MsBinaryLily) - 0.2.17